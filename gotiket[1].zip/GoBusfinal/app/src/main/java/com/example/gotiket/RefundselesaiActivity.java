package com.example.gotiket;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class RefundselesaiActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_refundselesai);

        Button kembali2 = (Button) findViewById(R.id.kembali2);

        kembali2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to InfoBangkuActivity (replace with your actual activity)
                Intent intent = new Intent(RefundselesaiActivity.this, MenuActivity.class);
                startActivity(intent);
            }
        });    }
}