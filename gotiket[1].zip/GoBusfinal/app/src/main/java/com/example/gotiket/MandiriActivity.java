package com.example.gotiket;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MandiriActivity extends AppCompatActivity {
    Button btn_mandiri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mandiri);

                btn_mandiri = findViewById(R.id.btn_mandiri);

                btn_mandiri.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // Navigate to InfoBangkuActivity (replace with your actual activity)
                        Intent intent = new Intent(MandiriActivity.this, infobangku.class);
                        startActivity(intent);
                    }
                });
            }
        }