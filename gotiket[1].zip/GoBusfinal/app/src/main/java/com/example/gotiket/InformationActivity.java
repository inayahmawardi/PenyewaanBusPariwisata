package com.example.gotiket;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.cardview.widget.CardView;

public class InformationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_information);

            // Find the CardView elements by their IDs
            CardView cardInfopariwisata = findViewById(R.id.cardInfopariwisata);
            CardView cardInfoRefund = findViewById(R.id.cardInfoRefund);
            CardView cardInfolong = findViewById(R.id.cardInfolong);
            CardView cardInfoshort = findViewById(R.id.cardInfoshort);
            CardView cardInfobigekonomi = findViewById(R.id.cardInfobigekonomi);
            CardView cardInfobigeksekutif = findViewById(R.id.cardInfobigeksekutif);
            CardView cardInfomedium = findViewById(R.id.cardInfomedium);
            CardView cardInfomediumeksekutif = findViewById(R.id.cardInfomediumeksekutif);

            // Set OnClickListener for Info Bangku CardView
            cardInfopariwisata.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Navigate to InfoBangkuActivity (replace with your actual activity)
                    Intent intent = new Intent(InformationActivity.this, infokursi.class);
                    startActivity(intent);
                }
            });

            // Set OnClickListener for Info Refund CardView
            cardInfoRefund.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Navigate to InfoRefundActivity (replace with your actual activity)
                    Intent intent = new Intent(InformationActivity.this, Inforefund_Activity.class);
                    startActivity(intent);
                }
            });

        cardInfolong.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to InfoRefundActivity (replace with your actual activity)
                Intent intent = new Intent(InformationActivity.this, ElfLong.class);
                startActivity(intent);
            }
        });

        cardInfoshort.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to InfoRefundActivity (replace with your actual activity)
                Intent intent = new Intent(InformationActivity.this, ElfShort.class);
                startActivity(intent);
            }
        });
        cardInfomedium.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to InfoRefundActivity (replace with your actual activity)
                Intent intent = new Intent(InformationActivity.this, medium.class);
                startActivity(intent);
            }
        });


        cardInfomediumeksekutif.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to InfoRefundActivity (replace with your actual activity)
                Intent intent = new Intent(InformationActivity.this, mediumEksekutif.class);
                startActivity(intent);
            }
        });

        cardInfobigekonomi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to InfoRefundActivity (replace with your actual activity)
                Intent intent = new Intent(InformationActivity.this, bigekonomi.class);
                startActivity(intent);
            }
        });

        cardInfobigeksekutif.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to InfoRefundActivity (replace with your actual activity)
                Intent intent = new Intent(InformationActivity.this, bigeksekutif.class);
                startActivity(intent);
            }
        });
        }
}