package com.example.gotiket;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class Mysqliterefund extends SQLiteOpenHelper {
    private static final String NAMA_DATABASES = "db_refund";
    private static final int VERSI_DATABASES = 3;
    static final String NAMA_TABEL = "tabel_tiket";
    static final String KOLOM_ID = "id";
    static final String KOLOM_NAMA = "nama";
    static final String KOLOM_TANGGAL = "tanggal";
    static final String KOLOM_TELEPON = "telepon";
    static final String KOLOM_BERANGKAT = "berangkat";
    static final String KOLOM_TUJUAN = "tujuan";
    static final String KOLOM_KURSI = "kursi";
    static final String KOLOM_KELAS = "kelas";
    static final String KOLOM_HARGA = "Harga";

    static final String KOLOM_DANAKEMBALI = "Dana Kembali";


    public Mysqliterefund(Context context) {
        super(context, NAMA_DATABASES, null, VERSI_DATABASES);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Buat tabel jika belum ada
        String CREATE_TABLE = "CREATE TABLE " + NAMA_TABEL + "("
                + KOLOM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + KOLOM_NAMA + " TEXT,"
                + KOLOM_TANGGAL + " TEXT,"
                + KOLOM_TELEPON + " TEXT,"
                + KOLOM_BERANGKAT + " TEXT,"
                + KOLOM_TUJUAN + " TEXT,"
                + KOLOM_KURSI + " TEXT,"
                + KOLOM_KELAS + " TEXT,"
                + KOLOM_HARGA + " TEXT,"
                + KOLOM_DANAKEMBALI + "TEXT "
                + ")";
        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Upgrade database jika versi berubah
        db.execSQL("DROP TABLE IF EXISTS " + NAMA_TABEL);
        onCreate(db);
    }
}
