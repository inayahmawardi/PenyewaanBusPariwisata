package com.example.gotiket;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class infokursi extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_infokursi);

        TextView tvcatatan = findViewById(R.id.tvcatatan);
        TextView tvharga = findViewById(R.id.tvharga);

        // Informasi Bis Eksekutif VIP
        String infoTextcatatan = "Catatan = \n"+
                "Uang muka atau down payment minimal 25% (dua puluh lima persen) dari harga sewa.\n"+
        "Dibayarkan paling lambat 3 hari setelah melakukan pemesanan.\n"+
        "Apabila uang muka belum kami terima, kami berhak me-release pemesanan Anda.\n"+
        "Jika terjadi perubahan jadwal atau reschedule silakan menghubungi marketing kami.\n"+
        "Biaya sewa tidak termasuk tol, parkir, driver tips (sukarela), tiket masuk objek wisata, penyebrangan kapal ferry.\n"+
        "Pembatalan H-7 sebelum keberangkatan dikenakan biaya ganti rugi 50% dari biaya sewa.\n"+
        "Pembatalan H-3 dan H-2 sebelum keberangkatan dikenakan biaya ganti rugi 75% dari biaya sewa.\n"+
        "Pembatalan mendadak H-1 dan di hari keberangkatan dikenakan 100% dari biaya sewa.\n";

        String infoTextharga = "Include Harga =\n "+
                "Harga tarif sewa bus pariwisata diatas include bus, driver, bbm.\n"+
                "Harga tarif sewa bus di Surabaya diatas belum termasuk HTM tempat wisata, biaya parkir,\n"+
                "biaya makan driver dan biaya penginapan driver bila menginap di luar kota Jogja.\n"+
                "Harga tarif sewa medium bus, big bus, jetbus shd diatas untuk tujuan dalam wilayah DIY\n"+
                "termasuk Borobudur, Ketep Pass. Untuk tujuan luar wilayah DIY akan dikenakan tarif yang berbeda,\n" +
                "silahkan hubungi kami untuk detail tujuan dan info harga terbaik.\n"+
                "Tujuan Wonosari dikenakan biaya tambahan Rp. 200.000,-\n"+
                "Biaya overtime adalah 10% / Jam dari tarif sewa bus.\n"+
                "Untuk rental bus pariwisata jogja fullday maksimal pemakaian pukul 22.00 WIB.\n"+
                "Harga tarif diatas tidak termasuk dalam periode High Season.\n";


        // Set teks pada TextView masing-masing
        tvcatatan.setText(infoTextcatatan);
        tvharga.setText(infoTextharga);

    }
}
