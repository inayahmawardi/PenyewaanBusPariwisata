package com.example.gotiket;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class mediumEksekutif extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medium_ekesekutif);

        TextView vipInfoTextView = findViewById(R.id.vipInfoTextView);
        TextView regularInfoTextView = findViewById(R.id.regularInfoTextView);
        TextView basicInfoTextView = findViewById(R.id.basicInfoTextView);

        // VIP Facilities
        String vipInfo = "VIP Fasilitas :\n" +
                "   - Kursi recleaning seat\n" +
                "   - Full AC Duckting / Kepala\n" +
                "   - Terdapat port charger gadget\n" +
                "   - Terdapat fasilitas hiburan LED TV\n" +
                "   - Dilengkapi dengan Wifi\n" +
                "   - Terdapat fasilitas hiburan karaoke dan DVD player\n" +
                "   - Tersedia pengharum ruangan\n" +
                "   - Terdapat lampu baca tiap kursi\n" +
                "   - Tersedia cool box\n" +
                "   - Tersedia bantal dan selimut\n" +
                "   - Bonus air mineral 600 ml\n" +
                "   - Makan\n" +
                "   - Tour leader\n" +
                "   - Tiket objek wisata\n" +
                "   - Dokumentasi\n" +
                "   - Baner foto\n" +
                "   - Baner bus";

        // Medium Facilities
        String mediumInfo = "Fasilitas Medium :\n" +
                "   - Kursi standar\n" +
                "   - Full AC Duckting / Kepala\n" +
                "   - Terdapat port charger gadget\n" +
                "   - Terdapat fasilitas hiburan LED TV\n" +
                "   - Dilengkapi dengan Wifi\n" +
                "   - Terdapat fasilitas hiburan karaoke dan DVD player\n" +
                "   - Tersedia pengharum ruangan\n" +
                "   - Terdapat lampu baca tiap kursi\n" +
                "   - Tersedia bantal\n" +
                "   - Bonus air mineral 330 ml";

        // Reguler Facilities
        String regularInfo = "Fasilitas Reguler :\n" +
                "   - Kursi standar\n" +
                "   - Full AC Duckting / Kepala\n" +
                "   - Terdapat port charger gadget\n" +
                "   - Terdapat fasilitas hiburan LED TV\n" +
                "   - Dilengkapi dengan Wifi\n" +
                "   - Terdapat fasilitas hiburan karaoke dan DVD player\n" +
                "   - Tersedia pengharum ruangan\n" +
                "   - Terdapat lampu baca tiap kursi\n" +
                "   - Tersedia bantal\n" +
                "   - Bonus air mineral 330 ml";

        // Set the text in the TextViews
        vipInfoTextView.setText(vipInfo);
        regularInfoTextView.setText(mediumInfo);
        basicInfoTextView.setText(regularInfo);
    }
}