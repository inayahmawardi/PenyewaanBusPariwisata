package com.example.gotiket;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class bigekonomi extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bigekonomi);

        TextView infovip = findViewById(R.id.infovip);
        TextView infomedium = findViewById(R.id.infomedium);
        TextView inforegular = findViewById(R.id.inforegular);

        // Informasi BIS Long VIP
        String infoTextVIP = "- Kapasitas sekitar 18-19 orang\n" +
                "- Fasilitas lengkap (AC, TV, musik, kursi reclining, wifi)\n" +
                "- Dimensi besar untuk perjalanan rombongan besar\n" +
                "- Ruang bagasi luas\n" +
                "- Pengharum ruangan\n" +
                "- Lampu baca tiap kursi\n" +
                "- Bantal dan selimut\n" +
                "- Bonus air mineral 600 ml\n" +
                "- Makan\n" +
                "- Tour leader\n" +
                "- Tiket objek wisata\n" +
                "- Dokumentasi\n" +
                "- Baner foto\n" +
                "- Baner bus";

        // Informasi BIS Long Medium
        String infoTextMedium =  "- Kapasitas sekitar 18-19 orang\n" +
                "- Fasilitas standar (AC, TV, musik)\n" +
                "- Dimensi sedang untuk perjalanan rombongan menengah\n" +
                "- Ruang bagasi\n" +
                "- Pengharum ruangan (Tergantung pada bus)\n" +
                "- Lampu baca (Tergantung pada bus)\n" +
                "- Bonus air mineral (Tergantung pada bus)\n" +
                "- Makan (Tergantung pada bus)\n" +
                "- Tour leader (Tergantung pada bus)\n" +
                "- Tiket objek wisata (Tergantung pada bus)\n" +
                "- Dokumentasi (Tergantung pada bus)\n" +
                "- Baner foto (Tergantung pada bus)\n" +
                "- Baner bus (Tergantung pada bus)";

        // Informasi BIS Long Regular
        String infoTextRegular = "- Kapasitas sekitar 18-19 orang\n" +
                "- Fasilitas dasar (AC)\n" +
                "- Dimensi standar untuk perjalanan umum\n" +
                "- Ruang bagasi\n" +
                "- Pengharum ruangan (Tergantung pada bus)\n" +
                "- Lampu baca (Tergantung pada bus)\n" +
                "- Bonus air mineral (Tergantung pada bus)\n" +
                "- Makan (Tergantung pada bus)\n" +
                "- Tour leader (Tergantung pada bus)\n" +
                "- Tiket objek wisata (Tergantung pada bus)\n" +
                "- Dokumentasi (Tergantung pada bus)\n" +
                "- Baner foto (Tergantung pada bus)\n" +
                "- Baner bus (Tergantung pada bus)";

        // Set teks pada TextView masing-masing
        infovip.setText(infoTextVIP);
        infomedium.setText(infoTextMedium);
        inforegular.setText(infoTextRegular);
    }
}
