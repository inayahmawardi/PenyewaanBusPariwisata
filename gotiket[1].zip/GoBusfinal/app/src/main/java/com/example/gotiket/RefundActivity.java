package com.example.gotiket;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatSpinner;

import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class RefundActivity extends AppCompatActivity {

    private TextInputEditText inputNama, inputTanggal, inputTelepon;
    private AppCompatSpinner spBerangkat, spTujuan, spKelas, spNoKursi;
    private MaterialButton btnCheckout;

    private Mysqliterefund mysqliterefund;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_refund);

        inputNama = findViewById(R.id.inputNama);
        inputTanggal = findViewById(R.id.inputTanggal);
        inputTelepon = findViewById(R.id.inputTelepon);

        spBerangkat = findViewById(R.id.spBerangkat);
        spTujuan = findViewById(R.id.spTujuan);
        spKelas = findViewById(R.id.spKelas);
        spNoKursi = findViewById(R.id.spNoKursi);

        btnCheckout = findViewById(R.id.btnCheckout);

        // Set up spinners
        setUpSpinners();

        // Set up button click listener
        btnCheckout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Handle button click, you can perform actions like validation, processing data, etc.
                simpanDataKeDatabase();
                showToast("Pesan button clicked");
            }
        });

        setUpDatePicker();

        // Initialize database
        mysqliterefund = new Mysqliterefund(this);
    }

    private void simpanDataKeDatabase() {
        String nama = inputNama.getText().toString();
        String tanggal = inputTanggal.getText().toString();
        String telepon = inputTelepon.getText().toString();
        String berangkat = spBerangkat.getSelectedItem().toString();
        String tujuan = spTujuan.getSelectedItem().toString();
        String kelas = spKelas.getSelectedItem().toString();
        String kursi = spNoKursi.getSelectedItem().toString();

        // Validate data before saving
        if (nama.isEmpty() || tanggal.isEmpty() || telepon.isEmpty()) {
            showToast("Harap lengkapi semua data");
            return;
        }

        SQLiteDatabase database = mysqliterefund.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(Mysqliterefund.KOLOM_NAMA, nama);
        values.put(Mysqliterefund.KOLOM_TANGGAL, tanggal);
        values.put(Mysqliterefund.KOLOM_TELEPON, telepon);
        values.put(Mysqliterefund.KOLOM_BERANGKAT, berangkat);
        values.put(Mysqliterefund.KOLOM_TUJUAN, tujuan);
        values.put(Mysqliterefund.KOLOM_KELAS, kelas);
        values.put(Mysqliterefund.KOLOM_KURSI, kursi);

        try {
            // Insert data into the table
            long newRowId = database.insertOrThrow(Mysqliterefund.NAMA_TABEL, null, values);
            showToast("Data berhasil disimpan dengan ID: " + newRowId);

            // Setelah data berhasil disimpan, buka RefundDetailActivity
            Intent intent = new Intent(RefundActivity.this, RefundDetailActivity.class);
            // Mengirim ID pesanan ke RefundDetailActivity
            intent.putExtra("ID_PESANAN", (int) newRowId);
            startActivity(intent);

        } catch (Exception e) {
            showToast("Gagal menyimpan data. Pastikan data valid.");
        } finally {
            // Close the database connection
            database.close();
        }
    }

    private void setUpDatePicker() {
        inputTanggal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Calendar calendar = Calendar.getInstance();
                int year = calendar.get(Calendar.YEAR);
                int month = calendar.get(Calendar.MONTH);
                int day = calendar.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog = new DatePickerDialog(
                        RefundActivity.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                                String selectedDate = String.format("%02d-%02d-%04d", day, month + 1, year);
                                inputTanggal.setText(selectedDate);
                            }
                        },
                        year, month, day);

                datePickerDialog.show();
            }
        });
    }

    private void setUpSpinners() {
        List<String> berangkatList = new ArrayList<>();
        berangkatList.add("Malang");
        berangkatList.add("Bekasi");
        berangkatList.add("Surabaya");
        berangkatList.add("Bandung");
        berangkatList.add("Jakarta");

        List<String> tujuanList = new ArrayList<>();
        tujuanList.add("Jakarta");
        tujuanList.add("Malang");
        tujuanList.add("Bekasi");
        tujuanList.add("Surabaya");
        tujuanList.add("Bandung");

        List<String> kelasList = new ArrayList<>();
        kelasList.add("VIP");
        kelasList.add("Reguler");
        kelasList.add("Biasa");

        List<String> noKursiList = new ArrayList<>();
        for (int i = 1; i <= 35; i++) {
            noKursiList.add(String.valueOf(i));
        }

        ArrayAdapter<String> berangkatAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                berangkatList
        );

        ArrayAdapter<String> tujuanAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                tujuanList
        );

        ArrayAdapter<String> kelasAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                kelasList
        );

        ArrayAdapter<String> noKursiAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                noKursiList
        );

        spBerangkat.setAdapter(berangkatAdapter);
        spTujuan.setAdapter(tujuanAdapter);
        spKelas.setAdapter(kelasAdapter);
        spNoKursi.setAdapter(noKursiAdapter);

        spBerangkat.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
                showToast("Selected: " + berangkatList.get(position));
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                // Do nothing
            }
        });

        spKelas.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
                showToast("Selected Kelas: " + kelasList.get(position));
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                // Do nothing
            }
        });
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
