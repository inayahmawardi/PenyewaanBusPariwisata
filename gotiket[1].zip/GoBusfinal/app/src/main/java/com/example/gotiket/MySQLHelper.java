package com.example.gotiket;

import android.content.Context;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class MySQLHelper extends SQLiteOpenHelper {
    private static final String NAMA_DATABASE = "database_tiket";
    private static final int VERSI_DATABASE = 2;

    static final String NAMA_TABEL = "tabel_tiket";
    static final String KOLOM_ID = "id";
    static final String KOLOM_NAMA = "nama";
    static final String KOLOM_TANGGAL = "tanggal";
    static final String KOLOM_TELEPON = "telepon";
    static final String KOLOM_BERANGKAT = "berangkat";
    static final String KOLOM_TUJUAN = "tujuan";
    static final String KOLOM_KURSI = "kursi";
    static final String KOLOM_KELAS = "kelas";
    static final String KOLOM_HARGA = "Harga";

    public MySQLHelper(Context context) {
        super(context, NAMA_DATABASE, null, VERSI_DATABASE);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String queryBuatTabel = "CREATE TABLE " + NAMA_TABEL + " (" +
                KOLOM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                KOLOM_NAMA + " TEXT, " +
                KOLOM_TANGGAL + " TEXT, " +
                KOLOM_TELEPON + " TEXT, " +
                KOLOM_BERANGKAT + " TEXT, " +
                KOLOM_TUJUAN + " TEXT, " +
                KOLOM_KURSI + " TEXT, " +
                KOLOM_KELAS + " TEXT, " +
                KOLOM_HARGA + " TEXT)";
        db.execSQL(queryBuatTabel);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int versiLama, int versiBaru) {
        if (versiLama < 2) {
            // Tambahkan perubahan skema database di sini
            db.execSQL("ALTER TABLE " + NAMA_TABEL + " ADD COLUMN " + KOLOM_KURSI + " TEXT;");
        }
        // Tangani peningkatan versi lainnya jika diperlukan
    }

    public static String getNamaTabel() {
        return NAMA_TABEL;
    }
        // ...

        // Tambahkan metode ini untuk mendapatkan cursor dengan data terakhir
        public Cursor getLastRecordCursor() {
            SQLiteDatabase db = this.getReadableDatabase();
            String query = "SELECT * FROM " + NAMA_TABEL + " ORDER BY " + KOLOM_ID + " DESC LIMIT 1";
            return db.rawQuery(query, null);
        }

    }


