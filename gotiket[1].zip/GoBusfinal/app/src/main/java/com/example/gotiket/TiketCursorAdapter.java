package com.example.gotiket;

public class TiketCursorAdapter {
}
