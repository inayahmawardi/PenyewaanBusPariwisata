package com.example.gotiket;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class medium extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medium);

        TextView vipInfoTextView = findViewById(R.id.vipInfomediumvip);
        TextView mediumInfoTextView = findViewById(R.id.regularInfomedium);
        TextView regulerInfoTextView = findViewById(R.id.basicInfomedium);

        // Informasi VIP
        String vipInfoText =  "VIP Fasilitas :\n" +
                "   - Kursi recleaning seat\n" +
                "   - Full AC Duckting / Kepala\n" +
                "   - Terdapat port charger gadget\n" +
                "   - Terdapat fasilitas hiburan LED TV\n" +
                "   - Dilengkapi dengan Wifi\n" +
                "   - Terdapat fasilitas hiburan karaoke dan DVD player\n" +
                "   - Tersedia pengharum ruangan\n" +
                "   - Terdapat lampu baca tiap kursi\n" +
                "   - Tersedia cool box\n" +
                "   - Tersedia bantal dan selimut\n" +
                "   - Bonus air mineral 600 ml\n" +
                "   - Makan\n" +
                "   - Tour leader\n" +
                "   - Tiket objek wisata\n" +
                "   - Dokumentasi\n" +
                "   - Baner foto\n" +
                "   - Baner bus";

        vipInfoTextView.setText(vipInfoText);

        // Informasi Medium
        String mediumInfoText = "Fasilitas Medium :\n" +
                "   - Kursi standar\n" +
                "   - Full AC Duckting / Kepala\n" +
                "   - Terdapat port charger gadget\n" +
                "   - Terdapat fasilitas hiburan LED TV\n" +
                "   - Dilengkapi dengan Wifi\n" +
                "   - Terdapat fasilitas hiburan karaoke dan DVD player\n" +
                "   - Tersedia pengharum ruangan\n" +
                "   - Terdapat lampu baca tiap kursi\n" +
                "   - Tersedia bantal\n" +
                "   - Bonus air mineral 330 ml";
        mediumInfoTextView.setText(mediumInfoText);

        // Informasi Reguler
        String regulerInfoText = "Fasilitas Reguler :\n" +
                "   - Kursi standar\n" +
                "   - Full AC Duckting / Kepala\n" +
                "   - Terdapat port charger gadget\n" +
                "   - Terdapat fasilitas hiburan LED TV\n" +
                "   - Dilengkapi dengan Wifi\n" +
                "   - Terdapat fasilitas hiburan karaoke dan DVD player\n" +
                "   - Tersedia pengharum ruangan\n" +
                "   - Terdapat lampu baca tiap kursi\n" +
                "   - Tersedia bantal\n" +
                "   - Bonus air mineral 330 ml";
        regulerInfoTextView.setText(regulerInfoText);
    }
}