package com.example.gotiket;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class ElfShort extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_elf_short);

        TextView infoelfshort = findViewById(R.id.infoelfshort);


        String infoText = "Kapasitas yang besar, yaitu sekitar 14-15 orang.\n" +
                "Fasilitas yang lengkap, seperti AC, TV, musik dan wifi.\n" +
                "Tersedia pengharum ruangan\n" +
                "Terdapat lampu baca tiap kursi\n" +
                "Tersedia bantal dan selimut\n" +
                "Bonus air mineral 600 ml\n" +
                "Makan\n" +
                "Tour leader\n" +
                "Tiket objek wisata\n" +
                "Dokumentasi\n" +
                "Baner foto\n" +
                "Baner bus";
        // Set the text in the TextView
        infoelfshort.setText(infoText);
    }
}