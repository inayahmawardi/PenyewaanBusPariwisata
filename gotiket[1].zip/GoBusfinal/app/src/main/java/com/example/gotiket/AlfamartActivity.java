package com.example.gotiket;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class AlfamartActivity extends AppCompatActivity {

    Button btn_alfa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alfamart);

        btn_alfa = findViewById(R.id.btn_alfa);

        btn_alfa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AlfamartActivity.this,infobangku.class);
                startActivity(intent);
            }
        });
    }
}