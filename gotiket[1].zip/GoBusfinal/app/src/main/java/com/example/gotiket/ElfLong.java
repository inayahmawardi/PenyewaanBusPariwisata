package com.example.gotiket;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class ElfLong extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_elf_long);

        TextView infoelflong = findViewById(R.id.infoelflong);


        String infoText = "Kapasitas yang besar, yaitu sekitar 18-19 orang.\n" +
                "Fasilitas yang lengkap, seperti AC, TV, musik, kursi yang bisa direbahkan dan wifi.\n" +
                "Dimensinya yang cukup besar, sehingga cocok untuk perjalanan rombongan besar\n" +
                "Ruang bagasi yang luas\n" +
                "Tersedia pengharum ruangan\n" +
                "Terdapat lampu baca tiap kursi\n" +
                "Tersedia bantal dan selimut\n" +
                "Bonus air mineral 600 ml\n" +
                "Makan\n" +
                "Tour leader\n" +
                "Tiket objek wisata\n" +
                "Dokumentasi\n" +
                "Baner foto\n" +
                "Baner bus";
        // Set the text in the TextView
        infoelflong.setText(infoText);
    }
}