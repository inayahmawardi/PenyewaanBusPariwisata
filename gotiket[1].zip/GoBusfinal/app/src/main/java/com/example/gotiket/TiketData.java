package com.example.gotiket;

public class TiketData {
    private final String nama;
    private final String tanggal;
    private final String telepon;
    private final String berangkat;
    private final String tujuan;
    private final String kelas;

    // Corrected constructor name to match the class name
    public TiketData(String nama, String tanggal, String telepon, String berangkat, String tujuan, String kelas) {
        this.nama = nama;
        this.tanggal = tanggal;
        this.telepon = telepon;
        this.berangkat = berangkat;
        this.tujuan = tujuan;
        this.kelas = kelas;
    }

    public String getNama() {
        return nama;
    }

    public String getTanggal() {
        return tanggal;
    }

    public String getTelepon() {
        return telepon;
    }

    public String getBerangkat() {
        return berangkat;
    }

    public String getTujuan() {
        return tujuan;
    }

    public String getKelas() {
        return kelas;
    }
}
