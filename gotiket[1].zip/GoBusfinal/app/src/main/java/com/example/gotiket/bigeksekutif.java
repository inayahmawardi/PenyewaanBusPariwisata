package com.example.gotiket;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class bigeksekutif extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bigeksekutif);

        TextView tvvip = findViewById(R.id.tvvip);
        TextView tvmedium = findViewById(R.id.tvmedium);
        TextView tvregular = findViewById(R.id.tvregular);

        // Informasi Bis Eksekutif VIP
        String infoTextVIP ="- Kapasitas sekitar 25-30 orang\n" +
                "- Fasilitas mewah (AC, TV layar datar, kursi elektrik, wifi)\n" +
                "- Dimensi besar untuk kenyamanan maksimal\n" +
                "- Ruang bagasi luas\n" +
                "- Pengharum ruangan\n" +
                "- Layanan pramugari\n" +
                "- Makanan dan minuman premium\n" +
                "- Bonus: Bantal, selimut, dan air mineral\n" +
                "- Hiburan pribadi\n" +
                "- Colokan listrik dan USB di setiap kursi";

        // Informasi Bis Eksekutif Medium
        String infoTextMedium = "- Kapasitas sekitar 25-30 orang\n" +
                "- Fasilitas standar (AC, TV, kursi reclining)\n" +
                "- Dimensi sedang untuk kenyamanan reguler\n" +
                "- Ruang bagasi\n" +
                "- Pengharum ruangan (Tergantung pada bus)\n" +
                "- Makanan dan minuman standar\n" +
                "- Bonus: Air mineral dan makanan ringan\n" +
                "- Colokan listrik (Tergantung pada bus)";

        // Informasi Bis Eksekutif Regular
        String infoTextRegular =  "- Kapasitas sekitar 20-25 orang\n" +
                "- Fasilitas dasar (AC)\n" +
                "- Dimensi standar untuk perjalanan umum\n" +
                "- Ruang bagasi\n" +
                "- Makanan dan minuman sederhana\n" +
                "- Bonus: Air mineral\n" +
                "- Colokan listrik (Tergantung pada bus)";

        // Set teks pada TextView masing-masing
        tvvip.setText(infoTextVIP);
        tvmedium.setText(infoTextMedium);
        tvregular.setText(infoTextRegular);
    }
}
