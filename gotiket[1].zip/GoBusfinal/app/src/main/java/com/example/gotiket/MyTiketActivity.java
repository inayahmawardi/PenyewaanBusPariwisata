package com.example.gotiket;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MyTiketActivity extends AppCompatActivity {

    private TextView tvDetailKelas, tvDetailTanggal, tvDetailNama, tvDetailTelepon,
            tvHargaTiket, tvNoKursi, tvDetailBerangkat, tvDetailTujuan;
    private MySQLHelper mySQLHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_tiket);

        // Initialize your TextViews and ImageView
        tvDetailKelas = findViewById(R.id.tvDetailKelas);
        tvDetailTanggal = findViewById(R.id.tvDetailTanggal);
        tvDetailNama = findViewById(R.id.tvDetailNama);
        tvDetailTelepon = findViewById(R.id.tvDetailTelepon);
        tvHargaTiket = findViewById(R.id.tvHargaTiket);
        tvNoKursi = findViewById(R.id.tvNoKursi);
        tvDetailBerangkat = findViewById(R.id.tvDetailBerangkat);
        tvDetailTujuan = findViewById(R.id.tvDetailTujuan);

        // Get the last record from the database
        MySQLHelper dbHelper = new MySQLHelper(this);
        Cursor cursor = dbHelper.getLastRecordCursor();

        if (cursor != null && cursor.moveToFirst()) {
            // Retrieve data from the cursor and update the UI
            String kelas = cursor.getString(cursor.getColumnIndex(MySQLHelper.KOLOM_KELAS));
            String tanggal = cursor.getString(cursor.getColumnIndex(MySQLHelper.KOLOM_TANGGAL));
            String nama = cursor.getString(cursor.getColumnIndex(MySQLHelper.KOLOM_NAMA));
            String telepon = cursor.getString(cursor.getColumnIndex(MySQLHelper.KOLOM_TELEPON));
            String harga = cursor.getString(cursor.getColumnIndex(MySQLHelper.KOLOM_HARGA));
            String noKursi = cursor.getString(cursor.getColumnIndex(MySQLHelper.KOLOM_KURSI));
            String berangkat = cursor.getString(cursor.getColumnIndex(MySQLHelper.KOLOM_BERANGKAT));
            String tujuan = cursor.getString(cursor.getColumnIndex(MySQLHelper.KOLOM_TUJUAN));

            // Update the UI with retrieved data
            tvDetailKelas.setText(kelas);
            tvDetailTanggal.setText(tanggal);
            tvDetailNama.setText(nama);
            tvDetailTelepon.setText(telepon);
            tvHargaTiket.setText("Rp. " + harga);
            tvNoKursi.setText(noKursi + "  Hari");
            tvDetailBerangkat.setText(berangkat);
            tvDetailTujuan.setText(tujuan);

            // You may need to handle loading the profile image here
            // For example, using an image loading library like Picasso or Glide:
            // Picasso.get().load("url_or_path_to_image").into(imageProfile);
        }

        // Close the cursor to avoid memory leaks
        if (cursor != null) {
            cursor.close();
        }
    }
}