package com.example.gotiket;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;

public class MenuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        // Find each MaterialCardView by its ID
        MaterialCardView informasiCard = findViewById(R.id.informasicard);
        MaterialCardView busCard = findViewById(R.id.buscard);
        MaterialCardView historyCard = findViewById(R.id.historycard);
        MaterialCardView refundCard = findViewById(R.id.refundcard);
        MaterialCardView mytiket = findViewById(R.id.mytiket);
        MaterialButton signOutButton = findViewById(R.id.out);

        informasiCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MenuActivity.this, InformationActivity.class);
                startActivity(intent);
                // Add actions for Informasi Card click
            }
        });

        busCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MenuActivity.this, home.class);
                startActivity(intent);
            }
        });

        historyCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MenuActivity.this, History1.class);
                startActivity(intent);
                // Add actions for History Card click
            }
        });

        mytiket.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MenuActivity.this, MyTiketActivity.class);
                startActivity(intent);
            }
        });

        refundCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MenuActivity.this, RefundActivity.class);
                startActivity(intent);
                // Add actions for Refund Card click
            }
        });

        signOutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Menambahkan logika sign out di sini (jika diperlukan)

                // Memberikan pesan toast (opsional)
                Toast.makeText(MenuActivity.this, "Signing Out...", Toast.LENGTH_SHORT).show();

                // Menutup aktivitas saat tombol "Sign Out" ditekan
                finish();
            }
        });
    }

    // Helper method to show a toast message
    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
