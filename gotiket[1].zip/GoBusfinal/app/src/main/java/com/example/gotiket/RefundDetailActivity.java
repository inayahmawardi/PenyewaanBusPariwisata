package com.example.gotiket;

import androidx.appcompat.app.AppCompatActivity;
import com.example.gotiket.Mysqliterefund;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;



public class RefundDetailActivity extends AppCompatActivity {

    private TextView tvNama, tvTanggal, tvTelepon, tvBerangkat, tvTujuan, tvKelas, tvHargaTiket, tvNoKursi, tvuangkembali;
    private Mysqliterefund mysqliterefund;
    private Button btnCheckout;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_refund_detail);

        tvNama = findViewById(R.id.tvDetailNama);
        tvTanggal = findViewById(R.id.tvDetailTanggal);
        tvTelepon = findViewById(R.id.tvDetailTelepon);
        tvBerangkat = findViewById(R.id.tvDetailBerangkat);
        tvTujuan = findViewById(R.id.tvDetailTujuan);
        tvNoKursi = findViewById(R.id.tvNoKursi);
        tvKelas = findViewById(R.id.tvDetailKelas);
        tvHargaTiket = findViewById(R.id.tvHargaTiket);
        tvuangkembali = findViewById(R.id.tvuangkembali); // Sesuaikan dengan ID yang sesuai di XML
        btnCheckout = findViewById(R.id.btnCheckout);

        btnCheckout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("DetailActivity", "Tombol Checkout diklik");
                Intent intent = new Intent(RefundDetailActivity.this, RefundselesaiActivity.class);
                startActivity(intent);
            }
        });

        mysqliterefund = new Mysqliterefund(this);

        // Mendapatkan ID pesanan dari intent
        int idPesanan = getIntent().getIntExtra("ID_PESANAN", -1);

        if (idPesanan != -1) {
            displayDetailData(idPesanan);
        } else {
            showToast("ID pesanan tidak valid.");
            finish();
        }
    }

    private void displayDetailData(int idPesanan) {
        SQLiteDatabase database = mysqliterefund.getReadableDatabase();
        Cursor cursor = database.rawQuery("SELECT * FROM " + MySQLHelper.getNamaTabel() + " WHERE " + MySQLHelper.KOLOM_ID + " = " + idPesanan, null);

        if (cursor.moveToFirst()) {
            String nama = cursor.getString(cursor.getColumnIndex(MySQLHelper.KOLOM_NAMA));
            String tanggal = cursor.getString(cursor.getColumnIndex(MySQLHelper.KOLOM_TANGGAL));
            String telepon = cursor.getString(cursor.getColumnIndex(MySQLHelper.KOLOM_TELEPON));
            String berangkat = cursor.getString(cursor.getColumnIndex(MySQLHelper.KOLOM_BERANGKAT));
            String tujuan = cursor.getString(cursor.getColumnIndex(MySQLHelper.KOLOM_TUJUAN));
            String kursi = cursor.getString(cursor.getColumnIndex(MySQLHelper.KOLOM_KURSI));
            String kelas = cursor.getString(cursor.getColumnIndex(MySQLHelper.KOLOM_KELAS));

            // Calculate ticket price based on the route, class, and display data
            int hargaTiket = calculateTicketPrice(berangkat, tujuan, kelas);

            // Calculate refund amount with 25% deduction
            double uangKembali = calculateRefundAmount(hargaTiket);

            // Display order data in TextViews
            tvNama.setText("Nama              : " + nama);
            tvTanggal.setText("Tanggal          : " + tanggal);
            tvTelepon.setText("Telepon          : " + telepon);
            tvBerangkat.setText("Berangkat      : " + berangkat);
            tvTujuan.setText("Tujuan            : " + tujuan);
            tvKelas.setText("Kelas              : " + kelas);
            tvNoKursi.setText("No Kursi         : " + kursi);
            tvHargaTiket.setText("Harga Tiket   : " + hargaTiket);
            tvuangkembali.setText("Uang Kembali : " + uangKembali);

            updateHargaDiDatabase(idPesanan, hargaTiket);


        } else {
            showToast("Data pesanan tidak ditemukan.");
            finish();
        }

        cursor.close();
        database.close();
    }

    private int calculateTicketPrice(String berangkat, String tujuan, String kelas) {
        int defaultPrice = 0;

        // Check the route, class, and return the corresponding ticket price
        if (berangkat.equalsIgnoreCase("Jakarta") && tujuan.equalsIgnoreCase("Bekasi")) {
            return getTicketPriceByClass(kelas, 35000, 25000, 15000);
        } else if (berangkat.equalsIgnoreCase("Jakarta") && tujuan.equalsIgnoreCase("Malang")) {
            return getTicketPriceByClass(kelas, 650000, 5700000, 380000);
        } else if (berangkat.equalsIgnoreCase("Jakarta") && tujuan.equalsIgnoreCase("Surabaya")) {
            return getTicketPriceByClass(kelas, 475000, 5700000, 380000);
        } else if (berangkat.equalsIgnoreCase("Jakarta") && tujuan.equalsIgnoreCase("Bandung")) {
            return getTicketPriceByClass(kelas, 195000, 109000, 81000);
        } else if (berangkat.equalsIgnoreCase("Bekasi") && tujuan.equalsIgnoreCase("Malang")) {
            return getTicketPriceByClass(kelas, 650000, 5700000, 380000);
        } else if (berangkat.equalsIgnoreCase("Bekasi") && tujuan.equalsIgnoreCase("Surabaya")) {
            return getTicketPriceByClass(kelas, 475000, 5700000, 380000);
        } else if (berangkat.equalsIgnoreCase("Bekasi") && tujuan.equalsIgnoreCase("Bandung")) {
            return getTicketPriceByClass(kelas, 195000, 109000, 81000);
        } else if (berangkat.equalsIgnoreCase("Surabaya") && tujuan.equalsIgnoreCase("Bekasi")) {
            return getTicketPriceByClass(kelas, 35000, 25000, 15000);
        } else if (berangkat.equalsIgnoreCase("Surabaya") && tujuan.equalsIgnoreCase("Malang")) {
            return getTicketPriceByClass(kelas, 650000, 5700000, 380000);
        } else if (berangkat.equalsIgnoreCase("Surabaya") && tujuan.equalsIgnoreCase("Jakarta")) {
            return getTicketPriceByClass(kelas, 475000, 5700000, 380000);
        } else if (berangkat.equalsIgnoreCase("Surabaya") && tujuan.equalsIgnoreCase("Bandung")) {
            return getTicketPriceByClass(kelas, 525000, 325000, 15000);
        } else if (berangkat.equalsIgnoreCase("Bandung") && tujuan.equalsIgnoreCase("Bekasi")) {
            return getTicketPriceByClass(kelas, 525000, 325000, 15000);
        } else if (berangkat.equalsIgnoreCase("Bandung") && tujuan.equalsIgnoreCase("Malang")) {
            return getTicketPriceByClass(kelas, 650000, 5700000, 380000);
        } else if (berangkat.equalsIgnoreCase("Bandung") && tujuan.equalsIgnoreCase("Surabaya")) {
            return getTicketPriceByClass(kelas, 475000, 5700000, 380000);
        } else if (berangkat.equalsIgnoreCase("Bandung") && tujuan.equalsIgnoreCase("Jakarta")) {
            return getTicketPriceByClass(kelas, 195000, 109000, 81000);
        }

        // Return default price if the route is not found
        return defaultPrice;
    }

    private int getTicketPriceByClass(String kelas, int vipPrice, int regulerPrice, int biasaPrice) {
        switch (kelas.toLowerCase()) {
            case "vip":
                return vipPrice;
            case "reguler":
                return regulerPrice;
            case "biasa":
                return biasaPrice;
            default:
                return 0;
        }
    }

    private double calculateRefundAmount(int hargaTiket) {
        // Deduct 25% for refund
        double pemotongan = 0.25;
        return hargaTiket - (hargaTiket * pemotongan);
    }

    private void updateHargaDiDatabase(int idPesanan, int hargaTiket) {
        SQLiteDatabase database = mysqliterefund.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(MySQLHelper.KOLOM_HARGA, String.valueOf(hargaTiket));

        int barisTerpengaruh = database.update(
                MySQLHelper.getNamaTabel(),
                values,
                MySQLHelper.KOLOM_ID + " = ?",
                new String[]{String.valueOf(idPesanan)}
        );

        if (barisTerpengaruh > 0) {
            Log.d("DetailActivity", "Harga Tiket diperbarui di database.");
        } else {
            Log.e("DetailActivity", "Gagal memperbarui Harga Tiket di database.");
        }

        database.close();
    }


    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
