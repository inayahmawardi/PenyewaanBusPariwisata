package com.example.gotiket;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class MetodePembayaranActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_metode_pembayaran);

        ImageView mandiri = findViewById(R.id.mandiri);
        ImageView bca = findViewById(R.id.bca);
        ImageView bni = findViewById(R.id.bni);
        ImageView mastercard = findViewById(R.id.kartukredit);
        ImageView alfa = findViewById(R.id.minimarket);
        ImageView indo = findViewById(R.id.minimarket2);

        // Set OnClickListener for Mandiri payment option
        mandiri.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MetodePembayaranActivity.this, MandiriActivity.class);
                startActivity(intent);
            }
        });

        // Set OnClickListener for BCA payment option
        bca.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MetodePembayaranActivity.this, BcaActivity.class);
                startActivity(intent);
            }
        });

        // Set OnClickListener for BNI payment option
        bni.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MetodePembayaranActivity.this, BniActivity.class);
                startActivity(intent);
            }
        });

        // Set OnClickListener for Mastercard payment option
        mastercard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                navigateToBayarActivity();
            }
        });

        // Set OnClickListener for Alfa payment option
        alfa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MetodePembayaranActivity.this, AlfamartActivity.class);
                startActivity(intent);
                // You may also want to add additional actions for Alfa click
            }
        });

        // Set OnClickListener for Indo payment option
        indo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MetodePembayaranActivity.this, indomaret.class);
                startActivity(intent);
                // You may also want to add additional actions for Indo click
            }
        });
    }

    // Method to navigate to BayarActivity
    private void navigateToBayarActivity() {
        // You may need to pass relevant data to BayarActivity using Intent.putExtra()
        Intent intent = new Intent(this, BayarActivity.class);
        startActivity(intent);
    }
}
