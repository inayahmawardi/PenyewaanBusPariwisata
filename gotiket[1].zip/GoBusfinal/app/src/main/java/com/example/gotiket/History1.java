package com.example.gotiket;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class History1 extends AppCompatActivity {

    private ListView listView;
    private MySQLHelper mySQLHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history1);

        listView = findViewById(R.id.listViewHistory1);
        mySQLHelper = new MySQLHelper(this);

        displayData();
    }

    private void displayData() {
        SQLiteDatabase database = mySQLHelper.getReadableDatabase();
        Cursor cursor = database.rawQuery("SELECT * FROM " + MySQLHelper.NAMA_TABEL, null);

        List<String> dataHistory = new ArrayList<>();

        if (cursor.moveToFirst()) {
            do {
                String nama = cursor.getString(cursor.getColumnIndex(MySQLHelper.KOLOM_NAMA));
                String tanggal = cursor.getString(cursor.getColumnIndex(MySQLHelper.KOLOM_TANGGAL));
                String telepon = cursor.getString(cursor.getColumnIndex(MySQLHelper.KOLOM_TELEPON));
                String berangkat = cursor.getString(cursor.getColumnIndex(MySQLHelper.KOLOM_BERANGKAT));
                String tujuan = cursor.getString(cursor.getColumnIndex(MySQLHelper.KOLOM_TUJUAN));
                String kelas = cursor.getString(cursor.getColumnIndex(MySQLHelper.KOLOM_KELAS));
                String harga = cursor.getString(cursor.getColumnIndex(MySQLHelper.KOLOM_HARGA));

                String historyItem = "======================================\n"
                        + "                      HISTORY TIKET BUS         \n"
                        + "=======================================\n"
                        + "Nama          : " + nama + "\n"
                        + "Tanggal       : " + tanggal + "\n"
                        + "Telepon       : " + telepon + "\n"
                        + "Berangkat     : " + berangkat + "\n"
                        + "Tujuan        : " + tujuan + "\n"
                        + "Kelas         : " + kelas + "\n"
                        + "Harga         : " + harga + "\n"
                        + "=======================================\n";

                dataHistory.add(historyItem);

            } while (cursor.moveToNext());

            ArrayAdapter<String> adapter = new ArrayAdapter<>(
                    this,
                    android.R.layout.simple_list_item_1,
                    dataHistory
            );

            listView.setAdapter(adapter);
        } else {
            showToast("Belum ada data tersimpan.");
        }

        cursor.close();
        database.close();
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
